<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'NuveManagerController@welcome')->name('welcome');
Route::get('/orthography', 'NuveManagerController@orthography')->name('orthography');
Route::get('/morphotactics', 'NuveManagerController@morphotactics')->name('morphotactics');

Route::get('/home', 'HomeController@index')->name('home');
Route::post('uploadLang','HomeController@uploadLangPost')->name("uploadLang");
Route::get('deleteLang/{lang}','HomeController@deleteLang')->name("deleteLang");

// Ajax Call
Route::post('/initLanguage','NuveManagerController@initLanguage')->name("initLanguage");



Route::get('/downloadFile/{lang}/{fileName}', function($lang, $fileName){
    $path = App\NuveManager::getLanguagesFiles($lang)[$fileName];
    return Storage::download($path);
})->name("downloadFile")->middleware('auth');

Route::get('/changeCurrentLanguage/{lang}', function($lang){
    App\NuveManager::changeCurrentLanguage($lang);
    return redirect()->route('welcome');
})->name("changeCurrentLanguage");

Route::post('/analyze', function(){
    $nuve = App\NuveManager::getNuve(App\NuveManager::getLanguage());
    $solutions = $nuve->analyze(request()->_text);
    $res = [];
    foreach($solutions as $solution){
        $res[] = $solution->analysis();
    }
    return response()->json($res);
})->name("analyze");

Route::post('/generate', function(){
    $nuve = App\NuveManager::getNuve(App\NuveManager::getLanguage());
    $textArr = explode(' ', request()->_text);
    $solutionLexicalForm = "";
    $solutionPhases = [];
    $status = false;
    try {
        $resultWord = $nuve->generate($textArr);
        for($i = 0; $i < $resultWord->allomorphCount(); $i++){
            $solutionLexicalForm .= $resultWord->allomorph($i)->surface() . ' ';
        }
        $solutionPhases = $resultWord->getSurfacesAfterEachPhase();
        $status = true;
    } catch (Exception $e) {
       $solutionPhases =  $e->getMessage();
    } catch (Throwable $e) {
        $solutionPhases =  $e->getMessage();
    }
    
    $solution = array(
        'phases' => $solutionPhases,
        'lexicalForm' => $solutionLexicalForm,
        'status' => $status,
    );
    return response()->json($solution);
})->name("generate");

/**
 * API Functions
 */

Route::post('/api/{lang}/morphotactics', function($lang){
    if($lang == "tr"){
        App\NuveManager::changeCurrentLanguage("tr_TR");
    }
    else if($lang == "uz"){
        App\NuveManager::changeCurrentLanguage("uz_UZ");
    }

    $nuve = App\NuveManager::getNuve(App\NuveManager::getLanguage());
    $solutions = $nuve->analyze(request()->_text);
    $res = [];
    foreach($solutions as $solution){
        $res[] = $solution->analysis();
    }
    return response()->json($res);
});

Route::post('/api/{lang}/orthography', function($lang){
    if($lang == "tr"){
        App\NuveManager::changeCurrentLanguage("tr_TR");
    }
    else if($lang == "uz"){
        App\NuveManager::changeCurrentLanguage("uz_UZ");
    }

    $nuve = App\NuveManager::getNuve(App\NuveManager::getLanguage());
    $textArr = explode(' ', request()->_text);
    $solutionLexicalForm = "";
    $solutionPhases = [];
    $status = false;
    try {
        $resultWord = $nuve->generate($textArr);
        for($i = 0; $i < $resultWord->allomorphCount(); $i++){
            $solutionLexicalForm .= $resultWord->allomorph($i)->surface() . ' ';
        }
        $solutionPhases = $resultWord->getSurfacesAfterEachPhase();
        $status = true;
    } catch (Exception $e) {
       $solutionPhases =  $e->getMessage();
    } catch (Throwable $e) {
        $solutionPhases =  $e->getMessage();
    }
    
    $solution = array(
        'phases' => $solutionPhases,
        'lexicalForm' => $solutionLexicalForm,
        'status' => $status,
    );
    return response()->json($solution);
});


Auth::routes();

