<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Language Managment</div>

                <div class="card-body">
                    <?php
                        $allLangs = App\NuveManager::isThereUploadedLanguage();
                    ?>
                    <?php if($allLangs): ?>
                        <?php $__currentLoopData = $allLangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col-md-12 p-3 mb-2 bg-primary text-white text-center">
                                    <strong><?php echo e($lang); ?></strong>
                                    <a class="DeleteTheLang" href="<?php echo e(route('deleteLang', $lang)); ?>" onclick="if(confirm('Are you sure want to delete this language (<?php echo e($lang); ?>)?')) return true; else return false;">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </div>
                            
                                <!-- TODO: List files of language -->
                                <?php
                                    $allFiles = App\NuveManager::getLanguagesFiles($lang);
                                ?>
                                <div class="col-md-3 offset-md-1 p-2 mr-4 mb-2 bg-success text-white text-center">
                                    <strong ><?php echo e(App\NuveManager::Orthography); ?></strong><br>
                                    <a class="DownloadLinkWithIcon" href="<?php echo e(route('downloadFile', ['lang' => $lang, 'fileName' => App\NuveManager::Orthography] )); ?>" target="_blank"><i class="fas fa-download"></i></a>
                                </div>
                                <div class="col-md-3 p-2 mr-4 mb-2 bg-success text-white text-center">
                                    <strong><?php echo e(App\NuveManager::Morphotactics); ?></strong><br>
                                    <a class="DownloadLinkWithIcon" href="<?php echo e(route('downloadFile', ['lang' => $lang, 'fileName' => App\NuveManager::Morphotactics] )); ?>" target="_blank"><i class="fas fa-download"></i></a>
                                </div>
                                <div class="col-md-3 p-2 mr-4 mb-2 bg-success text-white text-center">
                                    <strong><?php echo e(App\NuveManager::Suffixes); ?></strong><br>
                                    <a class="DownloadLinkWithIcon" href="<?php echo e(route('downloadFile', ['lang' => $lang, 'fileName' => App\NuveManager::Suffixes] )); ?>" target="_blank"><i class="fas fa-download"></i></a>
                                </div>
                                
                                <div class="col-md-3 offset-md-1 p-2 mr-4 mb-2 bg-success text-white text-center">
                                    <strong><?php echo e(App\NuveManager::Roots); ?></strong><br>
                                    <a class="DownloadLinkWithIcon" href="<?php echo e(route('downloadFile', ['lang' => $lang, 'fileName' => App\NuveManager::Roots] )); ?>" target="_blank"><i class="fas fa-download"></i></a>
                                </div>
                                <div class="col-md-3 p-2 mr-4 mb-2 bg-success text-white text-center">
                                    <strong><?php echo e(App\NuveManager::RName); ?></strong><br>
                                    <a class="DownloadLinkWithIcon" href="<?php echo e(route('downloadFile', ['lang' => $lang, 'fileName' => App\NuveManager::RName] )); ?>" target="_blank"><i class="fas fa-download"></i></a>
                                </div>
                                <div class="col-md-3 p-2 mr-4 mb-2 bg-success text-white text-center">
                                    <strong><?php echo e(App\NuveManager::RAbbrv); ?></strong><br>
                                    <a class="DownloadLinkWithIcon" href="<?php echo e(route('downloadFile', ['lang' => $lang, 'fileName' => App\NuveManager::RAbbrv] )); ?>" target="_blank"><i class="fas fa-download"></i></a>
                                </div>
                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>

                        <div class="p-3 mb-2 bg-danger text-white">You don't upload any language until now. There is just Turkish language by default.</div>

                    <?php endif; ?>
                </div>
            </div>
            
            <br><br><br>
            <div class="card">
                <div class="card-header">Upload New Language</div>

                <div class="card-body">
                    <?php if($message = Session::get('success')): ?>
 
                        <div class="alert alert-success alert-block">
 
                            <button type="button" class="close" data-dismiss="alert">×</button>
 
                            <strong><?php echo e($message); ?></strong>
 
                        </div>
 
                    <?php endif; ?>
 
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> There were some problems with your input.<br><br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
 
                    <form action="<?php echo e(route('uploadLang')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">
                            <label for="langCode" class="col-sm-3 col-form-label text-md-left"><?php echo e(__('Code')); ?></label>

                            <div class="col-md-6">
                                <input id="langCode" type="text" class="form-control<?php echo e($errors->has('code') ? ' is-invalid' : ''); ?>" name="code" value="<?php echo e(old('code')); ?>" required autofocus>
                                <small id="fileHelp" class="form-text text-muted">Language code like (tr)</small>
                                <?php if($errors->has('code')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('code')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="langCountryCode" class="col-sm-3 col-form-label text-md-left"><?php echo e(__('Country Code')); ?></label>

                            <div class="col-md-6">
                                <input id="langCountryCode" type="text" class="form-control<?php echo e($errors->has('countryCode') ? ' is-invalid' : ''); ?>" name="countryCode" value="<?php echo e(old('countryCode')); ?>" required>
                                <small id="fileHelp" class="form-text text-muted">Language country code like (TR)</small>
                                <?php if($errors->has('countryCode')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('countryCode')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label text-md-left"><?php echo e(__('Orthography File')); ?></label>

                            <div class="col-md-6">
                                <input type="file" class="form-control-file" name="orthographyFile" id="orthographyFile" aria-describedby="fileHelp" accept=".xml">
                                <small id="fileHelp" class="form-text text-muted">Please upload "orthography.xml" file.</small>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label text-md-left"><?php echo e(__('Morphotactics File')); ?></label>

                            <div class="col-md-6">
                                <input type="file" class="form-control-file" name="morphotacticsFile" id="morphotacticsFile" aria-describedby="fileHelp" accept=".xml">
                                <small id="fileHelp" class="form-text text-muted">Please upload "morphotactics.xml" file.</small>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label text-md-left"><?php echo e(__('Roots File')); ?></label>

                            <div class="col-md-6">
                                <input type="file" class="form-control-file" name="rootsFile" id="rootsFile" aria-describedby="fileHelp" accept=".csv">
                                <small id="fileHelp" class="form-text text-muted">Please upload "roots.csv" file.</small>
                            </div>
                        </div>

                        <!-- <div class="form-group row">
                            <label class="col-sm-3 col-form-label text-md-left"><?php echo e(__('Root Names File')); ?></label>

                            <div class="col-md-6">
                                <input type="file" class="form-control-file" name="rNameFile" id="rNameFile" aria-describedby="fileHelp" accept=".csv">
                                <small id="fileHelp" class="form-text text-muted">Please upload "rName.csv" file.</small>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label text-md-left"><?php echo e(__('Root Abbrv File')); ?></label>

                            <div class="col-md-6">
                                <input type="file" class="form-control-file" name="rAbbrvFile" id="rAbbrvFile" aria-describedby="fileHelp" accept=".csv">
                                <small id="fileHelp" class="form-text text-muted">Please upload "rAbbrv.csv" file.</small>
                            </div>
                        </div> -->

                        <div class="form-group row">
                            <label class="col-sm-3 col-form-label text-md-left"><?php echo e(__('Suffixes File')); ?></label>

                            <div class="col-md-6">
                                <input type="file" class="form-control-file" name="suffixesFile" id="suffixesFile" aria-describedby="fileHelp" accept=".csv">
                                <small id="fileHelp" class="form-text text-muted">Please upload "suffixes.csv" file.</small>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-3">
                                 <button type="submit" class="btn btn-primary">Start Upload</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>